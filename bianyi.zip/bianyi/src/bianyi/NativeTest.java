package bianyi;

public class NativeTest {
    public native void plusTest();

    //static {
    //    System.loadLibrary("NativeTestImpl");
    //}

    
}
